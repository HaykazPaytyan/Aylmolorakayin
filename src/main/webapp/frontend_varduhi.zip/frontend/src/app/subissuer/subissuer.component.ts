import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subissuer',
  templateUrl: './subissuer.component.html',
  styleUrls: ['./subissuer.component.css']
})
export class SubissuerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
